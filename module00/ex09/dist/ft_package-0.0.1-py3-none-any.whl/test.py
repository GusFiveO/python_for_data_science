def test():
	"""display test"""
	print(test)
